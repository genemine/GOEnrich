java -cp ./ edu.princeton.cs.function.GoTermFinder.GoServer go_basic_2018.obo goa_mouse_2018.gaf P 16000 &
#java -cp ./ edu.princeton.cs.function.GoTermFinder.GoServer go_basic_2018.obo goa_human_2018.gaf F 15001 &
#java -cp ./ edu.princeton.cs.function.GoTermFinder.GoServer go_basic_2018.obo goa_human_2018.gaf C 15002 &
