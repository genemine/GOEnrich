#!/usr/bin/perl

$genelistfile=$ARGV[0];
if (scalar @ARGV<2){$col=1;}else{$col=$ARGV[1];}


# main
$colid=$col-1;
$genelist=();
open FILE,"$genelistfile" or die;
while ($line=<FILE>) {
	chomp $line;
	@t=split '\t',$line;
	$genelist.=",$t[$colid]";
}
close FILE;
$genelist=substr $genelist,1;
print "$genelist\n*********\n";

$html="$genelistfile"."_goea.table";
system "java -cp ./ edu.princeton.cs.function.GoTermFinder.GoClient 15000 .05 $genelist>$html"


