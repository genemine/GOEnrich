/*
 * Created on May 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.princeton.cs.function.GoTermFinder;

import java.util.HashSet;

/**
 * @author mhibbs
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Gene {
	
	public String orf;
	public String name;
	public HashSet annotations;

	public Gene (String n) {
		name = n;
		annotations = new HashSet();
	}
	
	public void associate (GoTerm term) {
		annotations.add(term);
	}

}
