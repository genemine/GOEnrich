/*
 * Created on May 25, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.princeton.cs.function.GoTermFinder;

import java.util.HashSet;
import java.util.Iterator;

/**
 * @author mhibbs
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GoTerm {

	public String id;
	public String name;
	public String namespace;
	public HashSet parents;
	public HashSet children;
	public HashSet genes;
	public int totalAnnotations;
	public int queryAnnotations;
	public int counter;
	
	public GoTerm(String _id) {
		id = _id;
		totalAnnotations = 0;
		queryAnnotations = 0;
		counter = 0;
		parents = new HashSet();
		children = new HashSet();
		genes = new HashSet();
	}
	
	public boolean isAnnotated (Gene g) {
		return genes.contains(g);
	}
	
	public void annotate(Gene g) {
		if (!genes.contains(g)) {
			genes.add(g);
			g.annotations.add(this);
			totalAnnotations++;
		
			Iterator it = parents.iterator();
			while (it.hasNext()) {
				GoTerm p = (GoTerm)it.next();
				p.annotate(g);
			}
		}
	}

}
