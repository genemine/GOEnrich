/*
 * Created on May 27, 2005
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package edu.princeton.cs.function.GoTermFinder;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;

/**
 * @author mhibbs
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Ontology {
	
	public HashMap terms;
	public HashMap genes;
	public int numGenes;
	private double[] logFacts;
	
	/**
	 * Loads in the Gene Ontology hierarchy from the file name given
	 * @param oboName Name of the .obo file containing the hierarchy
	 */
	public Ontology (String oboName) {
		numGenes = 0;
		terms = new HashMap();
		genes = new HashMap();
		
		BufferedReader in;
		try {
			in = new BufferedReader(new FileReader(oboName));
			String line;
			
			while ((line = in.readLine()) != null) {
				//Looking for [TERM] lines...
				if (line.equalsIgnoreCase("[Term]")) {
					//Next line is required to be the id: line
					line = in.readLine();
					String id = line.substring(4);

					//System.out.println("Found term " + id);
					
					//Determine if this id already exists
					GoTerm node;
					Object obj = terms.get(id);
					if (obj != null) {
						node = (GoTerm)obj;
					}
					else {
						node = new GoTerm(id);
						terms.put(id,node);
						Integer idInt = new Integer(id.substring(3));
						terms.put(idInt,node);
					}
					
					//Now get the rest of the info for this term
					line = in.readLine();
					while ((line != null) && (!line.equals(""))) {
						int idx = line.indexOf(":");
						String tag = line.substring(0,idx);
						if (tag.equalsIgnoreCase("name")) {
							node.name = line.substring(idx+2);
						}
						else if (tag.equalsIgnoreCase("namespace")) {
							node.namespace = line.substring(idx+2);
						}
						else if (tag.equalsIgnoreCase("is_a")) {
							int idx2 = line.indexOf("!");
							String parentID = line.substring(idx+2,idx2-1);
							obj = terms.get(parentID);
							GoTerm parentNode;
							if (obj != null) {
								parentNode = (GoTerm)obj;
							}
							else {
								parentNode = new GoTerm(parentID);
								terms.put(parentID,parentNode);
								Integer parentIDInt = new Integer(parentID.substring(3));
								terms.put(parentIDInt,parentNode);
							}
							node.parents.add(parentNode);
							parentNode.children.add(node);
						}
						else if (tag.equalsIgnoreCase("relationship")) {
							int idx2 = line.indexOf("!");
							String parentID = line.substring(idx+2,idx2-1);
							idx2 = parentID.indexOf(" ");
							parentID = parentID.substring(idx2+1);
							obj = terms.get(parentID);
							GoTerm parentNode;
							if (obj != null) {
								parentNode = (GoTerm)obj;
							}
							else {
								parentNode = new GoTerm(parentID);
								terms.put(parentID,parentNode);
								Integer parentIDInt = new Integer(parentID.substring(3));
								terms.put(parentIDInt,parentNode);
							}
							node.parents.add(parentNode);
							parentNode.children.add(node);
						}
						else if (tag.equalsIgnoreCase("is_obsolete")) {
							String status = line.substring(idx+2);
							if (status.equalsIgnoreCase("true")) {
								terms.remove(node.id);
								terms.remove(node.id.substring(3));
							}
						}
						line = in.readLine();
					}
				}
			}
		}
		catch(FileNotFoundException e) {
			System.err.println("FileNotFound: " + oboName + ". Program aborted.");
			System.exit(0);
		}
		catch(IOException e) {
			System.err.println("IOException: " + oboName + ". Program aborted.");
			System.exit(0);
		}
	}//end Constructor
	
	/**
	 * Loads an annotation file into the ontology
	 * @param associationName Name of association file
	 * @return int - The number of annotations made
	 */
	
	public int numGenes(){
		return numGenes;
	}
	public int addAnnotations (String associationName, String aspect) {
		int numAnnotations = 0;
		
		try {
			BufferedReader in = new BufferedReader(new FileReader(
					associationName));
			String line = in.readLine();
			//System.out.println("1st line = " + line);
			while ((line != null)) {
				if ((!line.equals("")) && (!line.substring(0, 1).equals("!"))) {

					String[] parts = line.split("\t");
					/*
					 * Note on association file format:
					 * index/col# - field
					 * 2 - common name
					 * 4 - GO:##### string
					 * 8 - aspect (P, C, or F)
					 * 10 - orf (not req'd, may contain multiple with |s between)
					 */
					//If annotation is in the right aspect
					//System.out.println("Aspect of entry " + parts[4] + " is " + parts[8]);
					if (parts[8].equalsIgnoreCase(aspect)) {
						//Upper case all gene names
						parts[2] = parts[2].toUpperCase();
						parts[10] = parts[10].toUpperCase();

						//Locate this gene
						Gene g;
						Object obj = genes.get(parts[2]);
						if (obj != null) {
							g = (Gene) obj;
						}
						else {
							//System.out.println("Adding gene " + parts[2]);
							g = new Gene(parts[2]);
							numGenes++;
							genes.put(parts[2], g);
							g.orf = parts[10];
							if (!g.orf.equals("")) {
								int idx = g.orf.indexOf("|");
								if (idx != -1) {
									g.orf = g.orf.substring(0, idx);
								}
								//System.out.println("Adding ref to orf " + g.orf);
								genes.put(g.orf, g);
							}
						}

						//Get the GO term
						obj = terms.get(parts[4]);
						if (obj != null) {
							GoTerm t = (GoTerm) obj;
							t.annotate(g);
							numAnnotations++;
						}
						else {
							System.err.println("GO node " + parts[4] + " was not found, but is present in association.");
						}
					}
				}
				line = in.readLine();
				//System.out.println("line = " + line);
			}
		}
		catch(FileNotFoundException e) {
			System.err.println("FileNotFound: " + associationName + ". Program aborted.");
			System.exit(0);
		}
		catch(IOException e) {
			System.err.println("IOException: " + associationName + ". Program aborted.");
			System.exit(0);
		}
		
		//Pre-calculate the log factorials
		logFacts = new double [numGenes+1];
		logFacts[0] = 0;
		double current = 0;
		for (int i=1; i<numGenes+1; i++) {
			current += Math.log(i);
			logFacts[i] = current;
		}
		//System.out.println("Found " + numGenes + " unique genes in association file");
		//System.err.println("logFact(" + numGenes + ") = " + logFacts[numGenes]);		
		return numAnnotations;
	}
	
	public double logChoose (int n, int k) {
		if (n == 0) {
			if (k==0)
				return 0;
			else
				return Double.NEGATIVE_INFINITY;
		}
		if (k == 0) {
			return 0;
		}
		if (k == 1) {
			return Math.log(n);
		}
		if (n < k) {
			return Double.NEGATIVE_INFINITY;
		}
		//System.out.println(logFacts[n] + " - (" + logFacts[k] + " + " + logFacts[n-k] + ") = " +
		//		(logFacts[n] - (logFacts[k] + logFacts[n-k])));
		return logFacts[n] - (logFacts[k] + logFacts[n-k]);
	}

	public QueryResult[] goTermFind(String[] queryGeneNames, double pvalueCutoff) {
		HashSet queryGenesHS = new HashSet();
		for (int i=0; i<queryGeneNames.length; i++) {
			Object obj = genes.get(queryGeneNames[i].toUpperCase());
			if (obj != null) {
				queryGenesHS.add((Gene)obj);
			}
			else {
				System.err.println("WARNING: " + queryGeneNames[i].toUpperCase() + " was not found");
			}
		}		
		
		Gene[] queryGenes = (Gene[])queryGenesHS.toArray(new Gene[queryGenesHS.size()]);
		HashMap queries = new HashMap();
		for (int i=0; i<queryGenes.length; i++) {
			Iterator it = queryGenes[i].annotations.iterator();
			while (it.hasNext()) {
				GoTerm term = (GoTerm)it.next();
				//Only include the term if it has more than 1 annotations
				if (term.genes.size() > 1) {
					QueryResult query;
					Object obj = queries.get(term);
					if (obj != null) {
						query = (QueryResult)obj;
					}
					else {
						query = new QueryResult(term,numGenes,queryGenes.length);
						queries.put(term,query);
					}
					query.numQueryGenesInTerm++;
					query.queryGenesInTerm.add(queryGenes[i].name);
				}
			}
		}
		
		Collection collQ = queries.values();
		//System.out.println("Number of terms examined = " + collQ.size());
		Iterator it = collQ.iterator();
		int totResults=0;
		while (it.hasNext()) {
			QueryResult qr = (QueryResult)it.next();
			//System.out.println(qr);
			double sum = 0;
			/*
			for(int j=0; j<qr.numQueryGenesInTerm; j++) {
				System.out.println("Sum of logChoose = " + (logChoose(qr.totalGenesInTerm, j) +
				                logChoose(qr.totalGenes - qr.totalGenesInTerm, qr.numQueryGenes - j)));
				sum += Math.exp(logChoose(qr.totalGenesInTerm, j) +
				                logChoose(qr.totalGenes - qr.totalGenesInTerm, qr.numQueryGenes - j))
								/ Math.exp(logChoose(qr.totalGenes, qr.numQueryGenes));					            
			}*/
			for(int j=qr.numQueryGenes; j>=qr.numQueryGenesInTerm; j--) {
				sum += Math.exp(logChoose(qr.totalGenesInTerm, j) +
		                logChoose(qr.totalGenes - qr.totalGenesInTerm, qr.numQueryGenes - j)
						- logChoose(qr.totalGenes, qr.numQueryGenes));
			}
			
			//sum /= Math.exp(logChoose(qr.totalGenes, qr.numQueryGenes));
			
			//qr.pvalue = (1 - sum) * collQ.size();
			qr.pvalue = sum * collQ.size();
			if(qr.pvalue < pvalueCutoff) totResults++;
		}
		
		QueryResult[] allResults = (QueryResult[]) collQ.toArray(new QueryResult[collQ.size()]);
		Arrays.sort(allResults);
		
		QueryResult[] results = new QueryResult[totResults];
		for (int i=0; i<totResults; i++) {
			results[i] = allResults[i];
		}		
		
		return results;
	}
	
	/**
	 * Returns a reference to the GO term with the fewest annotations that
	 * is a common ancestor of the genes passed as arguments 
	 * @param g1 Gene name or ORF
	 * @param g2 Gene name or ORF
	 * @return reference to the GoTerm
	 */
	public GoTerm smallestCommonAncestor(String geneName1, String geneName2, String aspect) {
		GoTerm result = null;
		
		Gene gene1, gene2;
		Object obj = genes.get(geneName1);
		if (obj != null) {
			gene1 = (Gene)obj;
		}
		else {
			return null;
		}
		
		obj = genes.get(geneName2);
		if (obj != null) {
			gene2 = (Gene)obj;
		}
		else {
			return null;
		}
		
		if (aspect.equalsIgnoreCase("p")) {
			aspect = "biological_process";
		}
		else if (aspect.equalsIgnoreCase("c")) {
			aspect = "cellular_component";
		}
		else if (aspect.equalsIgnoreCase("f")) {
			aspect = "molecular_function";
		}
		
		//Find the intersection of the annotations
		HashSet termIntersection = new HashSet();
		Iterator it1 = gene1.annotations.iterator();
		while (it1.hasNext()) {
			GoTerm term1 = (GoTerm)it1.next();
			if (term1.namespace.equalsIgnoreCase(aspect)) {
				Iterator it2 = gene2.annotations.iterator();
				while (it2.hasNext()) {
					if (term1 == it2.next()) {
						termIntersection.add(term1);
						//System.err.println(term1.name);
					}
				}
			}
		}
		
		//Find the smallest common node and return that
		int smallest = Integer.MAX_VALUE;
		Iterator it = termIntersection.iterator();
		while (it.hasNext()) {
			GoTerm term = (GoTerm)it.next();
			if (term.totalAnnotations < smallest) {
				smallest = term.totalAnnotations;
				result = term;
			}
		}
		
		//System.err.println(result.name);
		
		return result;
	}
	
	public void resetTermCounters () {
		Iterator it = terms.keySet().iterator();
		while (it.hasNext()) {
			Object termName = it.next();
			GoTerm term = (GoTerm)terms.get(termName);
			term.counter = 0;
		}
	}	
	
	public boolean isInTerm (String gName, String termName) {
		GoTerm term;
		if(termName.charAt(0) == 'G') {
			term = (GoTerm) terms.get(termName);
		}
		else {
			Integer termIDInt = new Integer (termName);
			term = (GoTerm) terms.get(termIDInt);
		}
		
		if (term == null) {
			return false;
		}
		else {
			Gene g = (Gene) genes.get(gName);
			if (g == null) {
				return false;
			}
			else {
				return term.isAnnotated(g);
			}
		}
	}
	
}
